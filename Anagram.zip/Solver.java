package anagrams;

// CS145 Hybrid
// Programmers 
// 06/10/22
// Assignment 3: Anagrams
// An anagram  is  a  word  or  phrase  made  by  rearranging  the  letters  of  another  word  or  phrase.    For  example,  the  words 
// "Midterm" and "trimmed" are anagrams.  If you ignore spaces and capitalization and allow multiple words, a multi-word 
// Phrase  can  be  an  anagram  of  some  other  word  or  phrase.    For  example,  the  phrases  "Clint  Eastwood"  and  "old  west 
// Action" are anagrams. 
// For extra cridet I did I own non-trivial dictionary to use with this program.Mydtionary must include at least 50 words varying in length. 

import java.util.ArrayList;
import java.util.List;

public class Solver {

	public List<String> dictionary;
	public Inventory inputPhrase;
	public List<String> sortedInventory;
	public List<String> anagramSolution = new ArrayList<String>();

	public Solver(List<String> list) {
		dictionary = list;
	}

	public void print(String s, int max) {
		if (max < 0) {
			throw new IllegalArgumentException();
		} else {
			inputPhrase = new Inventory(s);
			sortInventory();
			if (inputPhrase.isEmpty()) {
				printOut();
			}

	
			if (max == 1) {
				for (String w1 : sortedInventory) {
					Inventory word1 = new Inventory(w1);
					if (word1.equals(inputPhrase)) {
						anagramSolution.add(w1);
						printOut();
						anagramSolution.remove(w1);
					}
				}
			} else { 
				String inputPhrase1;
				Inventory anagram;
				for (String w2 : sortedInventory) {
					Inventory word2 = new Inventory(w2);
					if (inputPhrase.subtract(word2) != null) {
						anagramSolution.add(w2);
						anagram = inputPhrase.subtract(word2);
						inputPhrase1 = anagram.toString();

						// When there is no maximum
						if (max == 0) {
							max = sortedInventory.size();
						}

						print(inputPhrase1, max - 1);
						anagramSolution.remove(w2);
						inputPhrase = new Inventory(s);
					}
				}
			}
		}
	}

	private void printOut() {
		if (anagramSolution.size() > 0) {
			String str = "["; 
			for (String word : anagramSolution) {
				str = str + word + ", ";
			}

			str = str.substring(0, str.length() - 2) + "]";
			Main.out.println(str); 
		}
	}

	private void sortInventory() {
		sortedInventory = new ArrayList<String>();
		for (String w : dictionary) {
			Inventory sort = new Inventory(w);
			if (inputPhrase.subtract(sort) != null) {
				sortedInventory.add(w);
			}
		}
	}
}
